## Projekty
- [[Upcycle House]]
- [[Resource Rows]]
- [Helsinki Olympic Stadium Refurbishment](https://www.miesarch.com/work/4874)