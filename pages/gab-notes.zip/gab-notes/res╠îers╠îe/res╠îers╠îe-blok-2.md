- https://dac.dk/en/exhibitions/copenhagen-in-common-what-we-have-in-common/
- https://livingcitiesforum.org/
- https://www.youtube.com/watch?v=V7FsUHYRfWs&ab_channel=MPavilion
- https://www.citiesandpeople.eu/
- https://space10.com/radical-shifts-for-our-urbanised-planet/
## Projekty
- [[Cable]] by [[Keller Easterling]]
- https://futurearchitectureplatform.org/projects/8889fc08-e3c3-486b-820b-a409f735827c/
## Knihy
- cities for future by space10