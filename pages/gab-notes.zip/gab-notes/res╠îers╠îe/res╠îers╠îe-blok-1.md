## Zdroje
- asi bych to tam nedaval ale zni to docela urgentne https://podcasts.apple.com/gb/podcast/maria-smith-its-depressing-how-much-architects-are/id1536913247?i=1000495641901
## Média
- [[Extrastatecraft]]
- [[A changemaker's guide to the future]]
- [[Building a Circular Future]]
- [[Volume Magazine]]
- [[Non-extractive architecture]]
- [[Future Architecture Book#^3a6ef7]]
## Osobnosti
- [[Keller Easterling]]
- [[Stephanie Carlisle]]
### Instituce
- [[Columbia-GSAPP]]
## Projekty
- [[Upcycle House]]
- [[Tally#^12322c]]
- [[Architecture 2030#^e4bb6c]]
- [[Under Construction]]
- [[Future Architecture]]
## Studia
- [[3XN]]
- [[Lendager]]
- [[white]]
## Citáty
- [[Léta jsem znečišťovala planetu. Nejsem těžařka - jsem architektka#^d06ebb]]
- "Je nepravděpodobné, že by se písek vyčerpal v celosvětovém měřítku. Pozorujeme však regionální nedostatek písku - a to jak fyzický nedostatek, který vzniká, když poptávka převyšuje fyzickou dostupnost, tak ekonomický nedostatek, který je důsledkem ztráty přístupu k ložiskům písku v důsledku konkurenčního využívání půdy nebo místního odporu k těžbě kvůli jejím dopadům na životní prostředí." - [[#^a30de0]]
- [[What constitutes good design?#^ff552b]] nebo [[What constitutes good design?#^9d8c8a]]
- [[Regenerative by Design#^fdfa82]] nebo [[Regenerative by Design#^07b347]]
## Články
- [Sand shortage](https://news.stanford.edu/2022/07/26/four-questions-eric-lambin-sand-shortage/) ^a30de0