## The Power of Infrastructure Space

### [[Keller Easterling]]
-  http://extrastatecraft.net/
- Extrastatecraft je operační systém moderního světa: panorama Dubaie, podmořské potrubí a kabely, které umožňují naši běžnou komunikaci, bezcelní zóny, standardizované rozměry kreditních karet anebo hyperkonzumeristická nákupní centra. Toto vše a ještě mnohem více. Lidstvem využívané infrastruktury určují neviditelná pravidla, jimiž se řídí prostory naší každodennosti, a činí z města klíčové místo moci a odporu v 21. století.
